//erfan zare 
//98411432
//hw9_az microprocessor

#include <mega32.h>

#include <alcd.h>


#include <stdio.h>
unsigned char i;
void usart_send_string(char *str);
void usart_clear(void);

void main(void)
{
    unsigned char c;

    DDRA = 0b00000000;
    DDRB = 0b00000000;
    DDRC = 0b00000000;
    DDRD = 0b00000000;

    // USART initialization
    // Communication Parameters: 8 Data, 1 Stop, No Parity
    // USART Receiver: On
    // USART Transmitter: On
    // USART Mode: Asynchronous
    // USART Baud Rate: 9600
    UCSRA=0x00;
    UCSRB=0x18;
    UCSRC=0x86;
    UBRRH=0x00;
    UBRRL=0x33;

    // Alphanumeric LCD initialization
    // Connections are specified in the
    // Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
    // RS - PORTC Bit 0
    // RD - PORTC Bit 1
    // EN - PORTC Bit 2
    // D4 - PORTC Bit 4
    // D5 - PORTC Bit 5
    // D6 - PORTC Bit 6
    // D7 - PORTC Bit 7
    // Characters/line: 16
    lcd_init(16);
    lcd_gotoxy(0, 0);

    while (1)
    {
        
        c = getchar();
        lcd_putchar(c);
        putchar(c);
        if (c == 'C')
        {
            lcd_clear();
            lcd_gotoxy(0, 0);
        }
        else if (c == 'N')
        {
            usart_send_string("\n\rErfan zare \n\r");
        }                      
        else if (c == 'c')
        {
            usart_clear();
        }
        if (c == 'M')
        {
            lcd_clear();
            lcd_gotoxy(0, 0);
            lcd_puts("Erfan zare");
        }
    }
}

void usart_send_string(char *str)
{
    for(i=0;str[i];i++)
    putchar(str[i]);
}

void usart_clear(void)
{
    for (i = 0; i < 24; i++)       
    {
        putchar('\n');        
        putchar('\r');
    }
}