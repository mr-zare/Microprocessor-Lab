/*******************************************************
erfan zare :98411432
Assembly Laboratory Experiment 5: LED Matrix
*******************************************************/

#include <mega32.h>

const unsigned char image_code[72]=
{
    0xFF,    //    0001        # # # # # # # # 
    0xFF,    //    0002        # # # # # # # # 
    0xFF,    //    0003        # # # # # # # # 
    0xFF,    //    0004        # # # # # # # # 
    0xFF,    //    0005        # # # # # # # # 
    0xFF,    //    0006        # # # # # # # # 
    0xFF,    //    0007        # # # # # # # # 
    0xFF,    //    0008        # # # # # # # # 
    0xFF,    //    0009        # # # # # # # # 
    0xFF,    //    000A        # # # # # # # # 
    0xFF,    //    000B        # # # # # # # # 
    0xFF,    //    000C        # # # # # # # # 
    0xFF,    //    000D        # # # # # # # # 
    0xFF,    //    000E        # # # # # # # # 
    0xFF,    //    000F        # # # # # # # # 
    0xFF,    //    0010        # # # # # # # # 
    0xF6,    //    0011        # # # # . # # . 
    0xF6,    //    0012        # # # # . # # . 
    0xF6,    //    0013        # # # # . # # . 
    0xF6,    //    0014        # # # # . # # . 
    0x00,    //    0015        . . . . . . . . 
    0xFF,    //    0016        # # # # # # # # 
    0x7E,    //    0017        . # # # # # # . 
    0x76,    //    0018        . # # # . # # . 
    0x76,    //    0019        . # # # . # # . 
    0x76,    //    001A        . # # # . # # . 
    0x00,    //    001B        . . . . . . . . 
    0xFF,    //    001C        # # # # # # # # 
    0xC3,    //    001D        # # . . . . # # 
    0xBD,    //    001E        # . # # # # . # 
    0x7E,    //    001F        . # # # # # # . 
    0x7E,    //    0020        . # # # # # # . 
    0x7E,    //    0021        . # # # # # # . 
    0x00,    //    0022        . . . . . . . . 
    0xFF,    //    0023        # # # # # # # # 
    0x7E,    //    0024        . # # # # # # . 
    0x7E,    //    0025        . # # # # # # . 
    0x7E,    //    0026        . # # # # # # . 
    0x7E,    //    0027        . # # # # # # . 
    0xBD,    //    0028        # . # # # # . # 
    0xC3,    //    0029        # # . . . . # # 
    0xFF,    //    002A        # # # # # # # # 
    0x89,    //    002B        # . . . # . . # 
    0x76,    //    002C        . # # # . # # . 
    0x76,    //    002D        . # # # . # # . 
    0x76,    //    002E        . # # # . # # . 
    0x00,    //    002F        . . . . . . . . 
    0xFF,    //    0030        # # # # # # # # 
    0x1F,    //    0031        . . . # # # # # 
    0xC3,    //    0032        # # . . . . # # 
    0xDC,    //    0033        # # . # # # . . 
    0xDC,    //    0034        # # . # # # . . 
    0xC3,    //    0035        # # . . . . # # 
    0x1F,    //    0036        . . . # # # # # 
    0xFF,    //    0037        # # # # # # # # 
    0xFF,    //    0038        # # # # # # # # 
    0xFF,    //    0039        # # # # # # # # 
    0xFF,    //    003A        # # # # # # # # 
    0xFF,    //    003B        # # # # # # # # 
    0xFF,    //    003C        # # # # # # # # 
    0xFF,    //    003D        # # # # # # # # 
    0xFF,    //    003E        # # # # # # # # 
    0xFF,    //    003F        # # # # # # # # 
    0xFF,    //    0040        # # # # # # # # 
    0xFF,    //    0041        # # # # # # # # 
    0xFF,    //    0042           # # # # # # # # 
    0xFF,     //       0043           # # # # # # # # 
    0xFF,    //       0044           # # # # # # # # 
    0xFF,    //       0045           # # # # # # # # 
    0xFF,    //     0046           # # # # # # # # 
    0xFF,    //       0047           # # # # # # # # 
    0xFF     //       0048           # # # # # # # # 
};

unsigned char column = 0;
unsigned char temp = 0;

void delay_2ms(void)
{
    TCNT0 = 0x06;
    TCCR0 = 0x03;
    while ((TIFR & 0x01) == 0);
    TCCR0 = 0;
    TIFR |= 0x01;
}

void draw(void)
{
    unsigned char row;
    unsigned char i;
    temp = column + 15;
    PORTB = 0x00;
    row = 0x01;
    for (i = 0; i < 8; i++)
    {
        PORTD = row;
        PORTC = image_code[temp];
        delay_2ms();
        temp--;
        row <<= 1;
    }  
    PORTD = 0x00;
    row = 0x01;
    for (i = 0; i < 8; i++)
    {
        PORTB = row;
        PORTC = image_code[temp];
        delay_2ms();
        temp--;
        row <<= 1;
    }
}

interrupt [TIM1_OVF] void timer1_ovf_isr(void)
{
    TCNT1H=0xCF2C >> 8;
    TCNT1L=0xCF2C & 0xff;
    column++;
    if (column == 56)
        column = 0;
}

void main(void)
{
    DDRA=0x00;
    PORTA=0x00;

    DDRB=0xFF;
    PORTB=0x00;

    DDRC=0xFF;
    PORTC=0xFF;

    DDRD=0xFF;
    PORTD=0xFF;

    TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
    TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (1<<CS11) | (1<<CS10);
    TCNT1H=0xCF;
    TCNT1L=0x2C;
    ICR1H=0x00;
    ICR1L=0x00;
    OCR1AH=0x00;
    OCR1AL=0x00;
    OCR1BH=0x00;
    OCR1BL=0x00;

    TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (1<<TOIE1) | (0<<OCIE0) | (0<<TOIE0);

    #asm("sei")

    while (1)
    {
         draw();
    }
}
