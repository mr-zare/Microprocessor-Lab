/*
Assembly Laboratory hw4
Name: erfan zare
Student Number: 98411432
*/

#include <mega32.h>

// Declare your global variables here
unsigned char h = 23; // Hour
unsigned char m = 58; // Minute
unsigned char s = 0;  // Second

unsigned char convert(unsigned char x)
{
    if (x == 0) return 0x3F;
    if (x == 1) return 0x06;
    if (x == 2) return 0x5B;
    if (x == 3) return 0x4F;
    if (x == 4) return 0x66;
    if (x == 5) return 0x6D;
    if (x == 6) return 0x7D;
    if (x == 7) return 0x07;
    if (x == 8) return 0x7F;
    if (x == 9) return 0x6F;  
}

unsigned char seg0 = 0;
unsigned char seg1 = 0;
unsigned char seg2 = 0;
unsigned char seg3 = 0;
unsigned char seg4 = 0;
unsigned char seg5 = 0;
unsigned char p = 1;

void delay_2ms(void)
{
    TCNT0 = 0x06;
    TCCR0 = 0x03;
    while ((TIFR & 0x01) == 0);
    TCCR0 = 0;
    TIFR |= 0x01;
}

void draw(void)
{
    PORTD = 0b11111110;
    PORTC = seg0;
    delay_2ms();
    PORTD = 0b11111101;
    PORTC = seg1 | (p << 7);
    delay_2ms();
    PORTD = 0b11111011;
    PORTC = seg2;
    delay_2ms();
    PORTD = 0b11110111;
    PORTC = seg3 | (p << 7);
    delay_2ms();
    PORTD = 0b11101111;
    PORTC = seg4;
    delay_2ms();
    PORTD = 0b11011111;
    PORTC = seg5 | (p << 7);
    delay_2ms();    
}

interrupt [TIM1_COMPA] void timer1_compa_isr(void)
{
    TCNT1H=0x85;
    TCNT1L=0xEE;
    s++;
    if (s == 60)
    {  
        s = 0;
        m++;
        if (m == 60)
        {   
            m = 0;
            h++;
            if (h == 24) h = 0;
        }
    }    
    p = 1 - p;
    seg0 = convert(h / 10);
    seg1 = convert(h % 10);
    seg2 = convert(m / 10);
    seg3 = convert(m % 10);
    seg4 = convert(s / 10);
    seg5 = convert(s % 10);    
}

void main(void)
{
    // Declare your local variables here

    // Input/Output Ports initialization

    // Port C initialization
    DDRC=0xFF;
    PORTC=0x00;
    
    // Port D initialization
    DDRD=0xFF;
    PORTD=0x01; 

    TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
    TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (1<<CS12) | (0<<CS11) | (0<<CS10);
    TCNT1H=0x85;
    TCNT1L=0xEE;
    ICR1H=0x00;
    ICR1L=0x00;
    OCR1AH=0x00;
    OCR1AL=0x00;
    OCR1BH=0x00;
    OCR1BL=0x00;

    TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (1<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (0<<TOIE0);

    #asm("sei")
    
    seg0 = convert(h / 10);
    seg1 = convert(h % 10);
    seg2 = convert(m / 10);
    seg3 = convert(m % 10);
    seg4 = convert(s / 10);
    seg5 = convert(s % 10);        

    while (1)
    {
        draw();
    }
}
