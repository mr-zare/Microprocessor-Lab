/*******************************************************
Microprocessor & Assembly Laboratory
Assignment 6
Name: erfan zare
Student Number: 98411432
*******************************************************/

#include <mega32.h>

// Alphanumeric LCD functions
#include <alcd.h>

// Declare your global variables here
unsigned char time[7] = {23, 58, 0, 0};

void display_hour(void)
{
    lcd_gotoxy(3, 1);
    lcd_putchar('0' + (time[0] / 10));
    lcd_gotoxy(4, 1);
    lcd_putchar('0' + (time[0] % 10));
}

void display_minute(void)
{
    lcd_gotoxy(6, 1);
    lcd_putchar('0' + (time[1] / 10));
    lcd_gotoxy(7, 1);
    lcd_putchar('0' + (time[1] % 10));
}

void display_second(void)
{
    lcd_gotoxy(9, 1);
    lcd_putchar('0' + (time[2] / 10));
    lcd_gotoxy(10, 1);
    lcd_putchar('0' + (time[2] % 10));
}

void display_fraction(void)
{
    lcd_gotoxy(12, 1);
    lcd_putchar('0' + time[3]);
}

// Timer1 overflow interrupt service routine
interrupt [TIM1_OVF] void timer1_ovf_isr(void)
{
    // Reinitialize Timer1 value
    TCNT1H=0xCF2C >> 8;
    TCNT1L=0xCF2C & 0xff;
    time[3]++;
    if (time[3] == 10)
    {   
        time[3] = 0;
        time[2]++;
        if (time[2] == 60)
        {
            time[2] = 0;
            time[1]++;
            if (time[1] == 60)
            {
                time[1] = 0;
                time[0]++;
                if (time[0] == 24)
                {
                    time[0] = 0;
                }   
                display_hour();
            } 
            display_minute();
        } 
        display_second();
    }
    display_fraction();
}

void main(void)
{
    // Declare your local variables here

    // Input/Output Ports initialization
    // Port A initialization
    DDRA=0b00000000;

    // Port B initialization
    DDRB=0b00000000;

    // Port C initialization
    DDRC=0b11111111;

    // Port D initialization
    DDRD=0b00000000;

    // Timer/Counter 1 initialization
    // Clock source: System Clock
    // Clock value: 125.000 kHz
    // Mode: Normal top=0xFFFF
    // OC1A output: Disconnected
    // OC1B output: Disconnected
    // Noise Canceler: Off
    // Input Capture on Falling Edge
    // Timer Period: 0.1 s
    // Timer1 Overflow Interrupt: On
    // Input Capture Interrupt: Off
    // Compare A Match Interrupt: Off
    // Compare B Match Interrupt: Off
    TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
    TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (1<<CS11) | (1<<CS10);
    TCNT1H=0xCF;
    TCNT1L=0x2C;
    ICR1H=0x00;
    ICR1L=0x00;
    OCR1AH=0x00;
    OCR1AL=0x00;
    OCR1BH=0x00;
    OCR1BL=0x00;

    // Timer(s)/Counter(s) Interrupt(s) initialization
    TIMSK=(0<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (1<<TOIE1) | (0<<OCIE0) | (0<<TOIE0);

    // Global enable interrupts
    #asm("sei")

    lcd_init(16);
    lcd_gotoxy(3, 0);
    lcd_puts("LCD Clock");     
    lcd_gotoxy(5, 1);
    lcd_putchar(':');
    lcd_gotoxy(8, 1);
    lcd_putchar(':'); 
    lcd_gotoxy(11, 1);
    lcd_putchar(':');
    
    display_hour();  
    display_minute();
    display_second();
    display_fraction();

    while (1)
    {
    // Place your code here

    }
}
